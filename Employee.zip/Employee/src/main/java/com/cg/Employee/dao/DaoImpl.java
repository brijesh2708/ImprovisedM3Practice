package com.cg.Employee.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.Employee.bean.Employee;
import com.cg.Employee.exception.UserNotFoundException;
@Repository
public class DaoImpl implements IDao{

	@Autowired
	MongoTemplate mongo;
	@Override
	public Employee addEmployee(Employee employee) {
		if(employee.getDoj()==null)
		{
			Date date=new Date();
			employee.setDoj(date);
		}
		mongo.save(employee);
		return employee;
	}
	
	@Override
	public List<Employee> viewEmployee() {
		
		return mongo.findAll(Employee.class);
	}

	@Override
	public Employee deleteEmployee(String empId) {
		
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		Employee employee=mongo.findOne(query, Employee.class);
		if(employee==null)
		{
	    	throw new UserNotFoundException(" User Not Found ");
		}else{
			mongo.remove(employee);
			
		}
		return employee;
	}

	@Override
	public Employee updateEmployee(String empId, Employee employee) {
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		employee.setEmpId(empId);
		mongo.findOne(query, Employee.class);
		mongo.save(employee);
		return employee;
		
	}

}
